

 </div><!--end content-->
            
</div><!--end main-->

</div><!--end class container-->
		
        <?php echo(get_option('analytics_code')); ?>
		<?php wp_footer(); ?>

	</body>

</html>